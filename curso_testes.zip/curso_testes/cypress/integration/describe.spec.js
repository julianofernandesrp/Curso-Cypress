/// <reference types="cypress"/>

it('A external test...', ()=>{ 

})

describe('Should group tests...', ()=>{
    it('A internal test...', ()=>{
        
    })
})