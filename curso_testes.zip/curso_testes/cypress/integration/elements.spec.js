/// <reference types="cypress" />

describe('Work with basic elements', ()=>{

    before(()=>{
        cy.visit('https://www.wcaquino.me/cypress/componentes.html')
    })

    beforeEach(()=>{
        cy.reload()
    })

    it('Text', ()=>{
        
        cy.get('body').should('contain', 'Cuidado')
        cy.get('span').should('contain', 'Cuidado')
        cy.get('.facilAchar').should('have.text', 'Cuidado onde clica, muitas armadilhas...')
    })


    it('Links', ()=>{
        cy.get('[href="#"]').click()
        cy.get('#resultado').should('have.text', 'Voltou!')

        cy.reload()
        cy.get('#resultado').should('have.not.text', 'Voltou!')
        cy.contains('Voltar').click()
        cy.get('#resultado').should('have.text', 'Voltou!')
    })


    it.only('TextFields', ()=>{
        cy.get('#formNome').type('Cypress Test')
        cy.get('#formNome').should('have.value', 'Cypress Test')


        cy.get('#elementosForm\\:sugestoes')
        .type('textarea')
        .should('have.value', 'textarea')

        cy.get('#tabelaUsuarios > :nth-child(2) > :nth-child(1) > :nth-child(6) > input')
        .type('???')

    })



})


// describe.only('Entrando no SIGAA', ()=>{
//     before(()=>{
//         cy.visit('https://si3.ufc.br/sigaa/verTelaLogin.do')
//     })

//     it('Colocando dados', ()=>{
//         cy.get('tbody > :nth-child(1) > td > input').type('julianofrp')
//         cy.get(':nth-child(2) > td > input').type('fernandes2002')
//         cy.get('tfoot > tr > td > input').click()
//     })
// })